import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

const monarchGold = Color(0xFFD4AF37);
const monarchGoldSoft = Color(0xFFF0D889);
const monarchBlack = Color(0xFF080808);
const monarchPanel = Color(0xFF131313);
const monarchMuted = Color(0xFF9F9A8E);
const apiBaseUrl = String.fromEnvironment(
  'MONARCH_API_BASE_URL',
  defaultValue: 'http://localhost:8000',
);

void main() => runApp(const MonarchApp());

class MonarchApp extends StatelessWidget {
  const MonarchApp({super.key});

  @override
  Widget build(BuildContext context) {
    final baseText = GoogleFonts.manropeTextTheme(
      ThemeData.dark().textTheme,
    );
    return MaterialApp(
      title: 'Monarch Analytics',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: monarchBlack,
        colorScheme: const ColorScheme.dark(
          primary: monarchGold,
          secondary: monarchGoldSoft,
          surface: monarchPanel,
        ),
        textTheme: baseText.copyWith(
          displaySmall: GoogleFonts.cormorantGaramond(
            fontSize: 40,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.5,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withValues(alpha: .05),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.white.withValues(alpha: .08)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.white.withValues(alpha: .08)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: monarchGold),
          ),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}

class LuxuryBackground extends StatefulWidget {
  const LuxuryBackground({required this.child, super.key});
  final Widget child;

  @override
  State<LuxuryBackground> createState() => _LuxuryBackgroundState();
}

class _LuxuryBackgroundState extends State<LuxuryBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 18),
  )..repeat();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) => CustomPaint(
        painter: LuxuryPainter(controller.value),
        child: widget.child,
      ),
    );
  }
}

class LuxuryPainter extends CustomPainter {
  LuxuryPainter(this.progress);
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = monarchBlack);
    final sweep = math.sin(progress * math.pi * 2) * .18;
    final glow = RadialGradient(
      center: Alignment(0.65 + sweep, -0.75),
      radius: 1.2,
      colors: [
        monarchGold.withValues(alpha: .16),
        const Color(0xFF4D3A0F).withValues(alpha: .07),
        Colors.transparent,
      ],
    );
    canvas.drawRect(rect, Paint()..shader = glow.createShader(rect));

    final haze = Paint()..color = monarchGold.withValues(alpha: .022);
    for (var i = 0; i < 7; i++) {
      final x = size.width * (0.12 + i * .17) +
          math.sin(progress * math.pi * 2 + i) * 24;
      final y = size.height * (.15 + (i % 3) * .31);
      canvas.drawCircle(Offset(x, y), 55 + i * 8, haze);
    }

    final crownPaint = Paint()
      ..color = monarchGold.withValues(alpha: .035 + .02 * math.sin(progress * math.pi * 2))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    final crown = Path()
      ..moveTo(size.width * .37, size.height * .16)
      ..lineTo(size.width * .42, size.height * .24)
      ..lineTo(size.width * .50, size.height * .13)
      ..lineTo(size.width * .58, size.height * .24)
      ..lineTo(size.width * .63, size.height * .16)
      ..lineTo(size.width * .60, size.height * .30)
      ..lineTo(size.width * .40, size.height * .30)
      ..close();
    canvas.drawPath(crown, crownPaint);
  }

  @override
  bool shouldRepaint(covariant LuxuryPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class MonarchMark extends StatelessWidget {
  const MonarchMark({this.compact = false, super.key});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 46 : 62,
          height: compact ? 46 : 62,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: monarchGold.withValues(alpha: .7)),
            boxShadow: [
              BoxShadow(
                color: monarchGold.withValues(alpha: .15),
                blurRadius: 22,
              ),
            ],
          ),
          child: Center(
            child: Text(
              'M',
              style: GoogleFonts.cormorantGaramond(
                color: monarchGoldSoft,
                fontSize: compact ? 29 : 40,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
        if (!compact) ...[
          const SizedBox(height: 12),
          Text(
            'MONARCH',
            style: GoogleFonts.manrope(
              fontSize: 10,
              color: monarchGoldSoft,
              letterSpacing: 5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ],
    );
  }
}

class Strategy {
  const Strategy({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.number,
    required this.description,
  });
  final String id;
  final String name;
  final String subtitle;
  final String number;
  final String description;
}

const strategies = [
  Strategy(
    id: 'msnr',
    name: 'MSNR Alchemist',
    subtitle: 'QM · QML · SBR · DIAMOND SETUPS',
    number: '01',
    description: 'Structure reversals with rare precision.',
  ),
  Strategy(
    id: 'ict',
    name: 'ICT Silver Bullet',
    subtitle: 'LIQUIDITY SWEEPS · FVG SNIPES',
    number: '02',
    description: 'Time-window execution around displacement.',
  ),
  Strategy(
    id: 'smc',
    name: 'SMC / AMD Tracker',
    subtitle: 'POWER OF 3 · MARKET STRUCTURE',
    number: '03',
    description: 'Read accumulation, manipulation, distribution.',
  ),
];

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LuxuryBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 26, 24, 12),
                  child: Column(
                    children: [
                      const MonarchMark(),
                      const SizedBox(height: 30),
                      Text(
                        'MONARCH',
                        style: GoogleFonts.manrope(
                          color: monarchGold,
                          letterSpacing: 6,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        'ANALYTICS',
                        style: GoogleFonts.cormorantGaramond(
                          color: Colors.white,
                          letterSpacing: 5,
                          fontSize: 32,
                          height: .95,
                        ),
                      ),
                      const SizedBox(height: 17),
                      Text(
                        'Clarity is the ultimate edge.',
                        style: GoogleFonts.manrope(
                          color: monarchMuted,
                          fontSize: 13,
                          letterSpacing: .3,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 28, 20, 30),
                sliver: SliverList.separated(
                  itemCount: strategies.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 15),
                  itemBuilder: (context, index) {
                    final strategy = strategies[index];
                    return StrategyCard(
                      strategy: strategy,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) =>
                              AnalysisScreen(strategy: strategy),
                        ),
                      ),
                    );
                  },
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(28, 0, 28, 28),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.shield_outlined,
                        size: 15,
                        color: monarchGold.withValues(alpha: .75),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'MAXIMUM RISK DISTANCE · 60 PIPS',
                        style: GoogleFonts.manrope(
                          color: monarchMuted,
                          fontSize: 9,
                          letterSpacing: 1.3,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StrategyCard extends StatelessWidget {
  const StrategyCard({required this.strategy, required this.onTap, super.key});
  final Strategy strategy;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.fromLTRB(21, 18, 17, 20),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: .6),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: monarchGold.withValues(alpha: .58)),
          boxShadow: [
            BoxShadow(
              color: monarchGold.withValues(alpha: .06),
              blurRadius: 25,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Text(
              strategy.number,
              style: GoogleFonts.cormorantGaramond(
                color: monarchGold,
                fontSize: 28,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    strategy.name,
                    style: GoogleFonts.cormorantGaramond(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    strategy.subtitle,
                    style: GoogleFonts.manrope(
                      color: monarchGoldSoft,
                      fontSize: 8.8,
                      letterSpacing: 1.1,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    strategy.description,
                    style: GoogleFonts.manrope(
                      color: monarchMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.arrow_forward_ios, color: monarchGold, size: 15),
          ],
        ),
      ),
    );
  }
}

class AnalysisScreen extends StatefulWidget {
  const AnalysisScreen({required this.strategy, super.key});
  final Strategy strategy;

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  final picker = ImagePicker();
  final instrumentController = TextEditingController();
  final timeframeController = TextEditingController(text: '15m');
  File? chart;
  Analysis? analysis;
  String? error;
  bool analyzing = false;

  @override
  void dispose() {
    instrumentController.dispose();
    timeframeController.dispose();
    super.dispose();
  }

  Future<void> chooseChart() async {
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 92,
    );
    if (picked == null) return;
    setState(() {
      chart = File(picked.path);
      analysis = null;
      error = null;
    });
  }

  Future<void> analyze() async {
    if (chart == null) {
      setState(() => error = 'Select a chart screenshot before analyzing.');
      return;
    }
    setState(() {
      analyzing = true;
      error = null;
      analysis = null;
    });
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$apiBaseUrl/analyze_monarch'),
      )
        ..fields['strategy'] = widget.strategy.id
        ..fields['instrument'] = instrumentController.text.trim()
        ..fields['timeframe'] = timeframeController.text.trim()
        ..files.add(await http.MultipartFile.fromPath('chart', chart!.path));
      final response = await request.send();
      final body = await response.stream.bytesToString();
      final decoded = jsonDecode(body) as Map<String, dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception(decoded['detail'] ?? 'Analysis service unavailable.');
      }
      setState(() => analysis = Analysis.fromJson(decoded));
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => analyzing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return LuxuryBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_ios_new, size: 18),
          ),
          title: Row(
            children: [
              const MonarchMark(compact: true),
              const SizedBox(width: 12),
              Text(
                'ANALYSIS DESK',
                style: GoogleFonts.manrope(
                  fontSize: 11,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w800,
                  color: monarchGoldSoft,
                ),
              ),
            ],
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 36),
          children: [
            Text(
              '${widget.strategy.name} Engine',
              style: GoogleFonts.cormorantGaramond(
                fontSize: 34,
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              widget.strategy.subtitle,
              style: GoogleFonts.manrope(
                color: monarchGold,
                fontSize: 9,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 24),
            _buildChartPicker(),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: instrumentController,
                    textCapitalization: TextCapitalization.characters,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Instrument',
                      hintText: 'EURUSD',
                      labelStyle: TextStyle(color: monarchMuted),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: timeframeController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Timeframe',
                      hintText: '15m',
                      labelStyle: TextStyle(color: monarchMuted),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 54,
              child: ElevatedButton(
                onPressed: analyzing ? null : analyze,
                style: ElevatedButton.styleFrom(
                  backgroundColor: monarchGold,
                  foregroundColor: Colors.black,
                  disabledBackgroundColor: monarchGold.withValues(alpha: .45),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  textStyle: GoogleFonts.manrope(
                    fontSize: 11,
                    letterSpacing: 1.8,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                child: analyzing
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text('ANALYZE CHART'),
              ),
            ),
            if (error != null) ...[
              const SizedBox(height: 16),
              _Notice(text: error!, danger: true),
            ],
            if (analysis != null) ...[
              const SizedBox(height: 24),
              AnalysisPanel(analysis: analysis!),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildChartPicker() {
    return GestureDetector(
      onTap: chooseChart,
      child: Container(
        height: 220,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: .5),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: monarchGold.withValues(alpha: .65),
            style: BorderStyle.solid,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: chart == null
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.add_photo_alternate_outlined,
                    color: monarchGold.withValues(alpha: .9),
                    size: 36,
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'UPLOAD CHART SCREENSHOT',
                    style: GoogleFonts.manrope(
                      color: Colors.white,
                      fontSize: 11,
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    'PNG · JPG · WEBP  /  TAP TO SELECT',
                    style: GoogleFonts.manrope(
                      color: monarchMuted,
                      fontSize: 9,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              )
            : Stack(
                fit: StackFit.expand,
                children: [
                  Image.file(chart!, fit: BoxFit.cover),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      color: Colors.black.withValues(alpha: .72),
                      child: Text(
                        'TAP TO REPLACE CHART',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.manrope(
                          color: monarchGoldSoft,
                          fontSize: 9,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.text, this.danger = false});
  final String text;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: (danger ? Colors.redAccent : monarchGold).withValues(alpha: .1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: (danger ? Colors.redAccent : monarchGold)
              .withValues(alpha: .45),
        ),
      ),
      child: Text(
        text,
        style: GoogleFonts.manrope(
          color: danger ? Colors.red[200] : monarchGoldSoft,
          fontSize: 11,
          height: 1.45,
        ),
      ),
    );
  }
}

class Analysis {
  Analysis({
    required this.strategy,
    required this.instrument,
    required this.timeframe,
    required this.marketBias,
    required this.setupStatus,
    required this.entryZone,
    required this.stopLoss,
    required this.slPips,
    required this.takeProfitTargets,
    required this.technicalConfluence,
    required this.invalidation,
    required this.analystNote,
    required this.riskNote,
  });

  factory Analysis.fromJson(Map<String, dynamic> json) => Analysis(
        strategy: json['strategy'] as String? ?? 'Monarch',
        instrument: json['instrument'] as String? ?? 'Unknown',
        timeframe: json['timeframe'] as String? ?? 'Unknown',
        marketBias: json['market_bias'] as String? ?? 'No Trade',
        setupStatus: json['setup_status'] as String? ?? 'No Trade',
        entryZone: json['entry_zone'] as String? ?? 'No Trade',
        stopLoss: json['stop_loss'] as String? ?? 'No Trade',
        slPips: (json['sl_pips'] as num?)?.toDouble() ?? 60,
        takeProfitTargets:
            List<String>.from(json['take_profit_targets'] as List? ?? []),
        technicalConfluence:
            List<String>.from(json['technical_confluence'] as List? ?? []),
        invalidation: json['invalidation'] as String? ?? '',
        analystNote: json['analyst_note'] as String? ?? '',
        riskNote: json['risk_note'] as String? ?? '',
      );

  final String strategy;
  final String instrument;
  final String timeframe;
  final String marketBias;
  final String setupStatus;
  final String entryZone;
  final String stopLoss;
  final double slPips;
  final List<String> takeProfitTargets;
  final List<String> technicalConfluence;
  final String invalidation;
  final String analystNote;
  final String riskNote;
}

class AnalysisPanel extends StatelessWidget {
  const AnalysisPanel({required this.analysis, super.key});
  final Analysis analysis;

  @override
  Widget build(BuildContext context) {
    final noTrade = analysis.marketBias == 'No Trade' ||
        analysis.setupStatus == 'No Trade';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: monarchPanel.withValues(alpha: .92),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: monarchGold.withValues(alpha: .6)),
        boxShadow: [
          BoxShadow(
            color: monarchGold.withValues(alpha: .06),
            blurRadius: 24,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'MONARCH READOUT',
                  style: GoogleFonts.manrope(
                    color: monarchGold,
                    fontSize: 10,
                    letterSpacing: 1.8,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              _Pill(
                text: analysis.setupStatus.toUpperCase(),
                positive: !noTrade,
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _Metric(
                  label: 'MARKET BIAS',
                  value: analysis.marketBias,
                  accent: analysis.marketBias == 'Bullish'
                      ? const Color(0xFF75D6A4)
                      : analysis.marketBias == 'Bearish'
                          ? const Color(0xFFED8D82)
                          : monarchGoldSoft,
                ),
              ),
              Expanded(
                child: _Metric(
                  label: 'SL DISTANCE',
                  value: '${analysis.slPips.toStringAsFixed(0)} pips',
                  accent: monarchGoldSoft,
                ),
              ),
            ],
          ),
          const SizedBox(height: 19),
          const Divider(color: Color(0xFF332D1C)),
          const SizedBox(height: 15),
          _Readout(label: 'ENTRY ZONE', value: analysis.entryZone),
          _Readout(label: 'STOP LOSS', value: analysis.stopLoss),
          _Readout(
            label: 'TP TARGETS',
            value: analysis.takeProfitTargets.join('  •  '),
          ),
          const SizedBox(height: 9),
          _SectionTitle(label: 'TECHNICAL CONFLUENCE'),
          ...analysis.technicalConfluence.map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('◆ ', style: TextStyle(color: monarchGold)),
                  Expanded(
                    child: Text(
                      item,
                      style: GoogleFonts.manrope(
                        color: Colors.white.withValues(alpha: .82),
                        fontSize: 11,
                        height: 1.35,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 9),
          _SectionTitle(label: 'ANALYST NOTE'),
          Text(
            analysis.analystNote,
            style: GoogleFonts.manrope(
              color: Colors.white.withValues(alpha: .85),
              fontSize: 11,
              height: 1.55,
            ),
          ),
          const SizedBox(height: 14),
          _SectionTitle(label: 'INVALIDATION'),
          Text(
            analysis.invalidation,
            style: GoogleFonts.manrope(
              color: monarchMuted,
              fontSize: 11,
              height: 1.45,
            ),
          ),
          const SizedBox(height: 16),
          _Notice(text: analysis.riskNote),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({
    required this.label,
    required this.value,
    required this.accent,
  });
  final String label;
  final String value;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.manrope(
            color: monarchMuted,
            fontSize: 8,
            letterSpacing: 1.1,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          value,
          style: GoogleFonts.cormorantGaramond(
            color: accent,
            fontSize: 22,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _Readout extends StatelessWidget {
  const _Readout({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 82,
            child: Text(
              label,
              style: GoogleFonts.manrope(
                color: monarchGold,
                fontSize: 8,
                letterSpacing: .8,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: GoogleFonts.manrope(
                color: Colors.white.withValues(alpha: .88),
                fontSize: 12,
                height: 1.35,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Text(
        label,
        style: GoogleFonts.manrope(
          color: monarchGold,
          fontSize: 8,
          letterSpacing: 1.1,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.positive});
  final String text;
  final bool positive;

  @override
  Widget build(BuildContext context) {
    final color = positive ? const Color(0xFF75D6A4) : monarchGoldSoft;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: .55)),
      ),
      child: Text(
        text,
        style: GoogleFonts.manrope(
          color: color,
          fontSize: 8,
          letterSpacing: .8,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}