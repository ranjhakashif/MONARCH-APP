package com.monarch.analytics

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
