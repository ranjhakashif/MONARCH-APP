# Monarch

Flutter mobile client for the Monarch Analytics platform.

## Run

```bash
cd monarch-mobile
flutter pub get
flutter run --dart-define=MONARCH_API_BASE_URL=http://10.0.2.2:8000
```

For a physical device, replace the URL with the computer's local network
address. For a deployed FastAPI service, pass its HTTPS URL.

## Build

```bash
flutter build apk --release \
  --dart-define=MONARCH_API_BASE_URL=https://your-api.example.com
```
