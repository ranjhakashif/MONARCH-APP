# Monarch Analytics

Monarch is a dark-luxury trading analysis platform with a Flutter mobile client and a FastAPI Claude Vision backend for structured chart readouts.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- `cd monarch-backend && uvicorn app.main:app --reload --port 8000` — run the chart-analysis API
- `cd monarch-mobile && flutter pub get && flutter run --dart-define=MONARCH_API_BASE_URL=http://10.0.2.2:8000` — run the mobile client

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Mobile: Flutter/Dart, image_picker, Google Fonts
- AI: Anthropic Claude Vision via a server-side `ANTHROPIC_API_KEY`

## Where things live

- `monarch-mobile/lib/main.dart` — Monarch dashboard, strategy cards, chart upload flow, animated background, and analysis readout
- `monarch-backend/app/main.py` — FastAPI routes
- `monarch-backend/app/claude.py` — Claude Vision request, strategy prompts, and 60-pip enforcement
- `monarch-backend/app/strategies.py` — strategy-specific analysis rules
- `monarch-backend/app/schemas.py` — typed analysis response and stop-loss validation

## Architecture decisions

- The mobile app talks to a configurable API URL through `MONARCH_API_BASE_URL`, allowing the same APK to target local, staging, or deployed backends.
- Strategy-specific rules live on the server so risk controls cannot be bypassed by the mobile client.
- The 60-pip stop-loss cap is enforced both in the Claude instruction and in server-side response handling; over-limit setups become `No Trade`.

## Product

Users choose between three trading frameworks, upload a chart screenshot, provide optional instrument/timeframe context, and receive a structured readout containing bias, entry, stop loss, targets, confluence, and invalidation.

## User preferences

- Preserve the Monarch dark luxury visual language: near-black surfaces, metallic gold `#D4AF37`, premium serif display type, and subtle animated background treatment.

## Gotchas

- Keep `ANTHROPIC_API_KEY` server-side only; the Flutter app must never receive it.
- Use `flutter build apk --release --dart-define=MONARCH_API_BASE_URL=<https-url>` for release builds.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
