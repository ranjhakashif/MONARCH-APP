# Monarch Analytics backend

FastAPI service for chart uploads and Claude Vision analysis.

## Local run

```bash
cd monarch-backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set ANTHROPIC_API_KEY in .env
uvicorn app.main:app --reload --port 8000
```

The API is available at `POST /analyze_monarch` and accepts:

- `chart`: PNG, JPEG, or WEBP upload
- `strategy`: `msnr`, `ict`, or `smc`
- `instrument`: optional symbol such as EURUSD
- `timeframe`: optional timeframe such as 15m

The model prompt and response validator both enforce Monarch's maximum 60-pip
stop-loss rule. A setup that needs more than 60 pips is returned as `No Trade`.

## Deployment

Run with:

```bash
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```
