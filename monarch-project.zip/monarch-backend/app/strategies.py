from dataclasses import dataclass


@dataclass(frozen=True)
class StrategyPrompt:
    name: str
    subtitle: str
    rules: str


STRATEGIES: dict[str, StrategyPrompt] = {
    "msnr": StrategyPrompt(
        name="MSNR Alchemist",
        subtitle="QM, QML, SBR, Diamond Setups",
        rules=(
            "Prioritize Market Structure Narrative Reversal logic. Inspect for a clear "
            "trend, displacement, liquidity raid, Quasimodo (QM), Quasimodo Level (QML), "
            "Support/Break/Retest (SBR), and Diamond formations. Only call a setup valid "
            "when the structure is visible and the entry has a defined invalidation."
        ),
    ),
    "ict": StrategyPrompt(
        name="ICT Silver Bullet",
        subtitle="Liquidity Sweeps, FVG Snipes",
        rules=(
            "Prioritize ICT Silver Bullet logic. Inspect for a time-window context when "
            "visible, buy-side or sell-side liquidity sweeps, displacement, fair value "
            "gaps, consequent encroachment, and a precise retracement entry. Do not "
            "invent a time window or level that is not visible."
        ),
    ),
    "smc": StrategyPrompt(
        name="SMC / AMD Tracker",
        subtitle="Power of 3, Market Structure",
        rules=(
            "Prioritize Smart Money Concepts and Accumulation-Manipulation-Distribution. "
            "Inspect for accumulation, manipulation, distribution, order blocks, breaks "
            "of structure, changes of character, liquidity pools, and premium/discount."
        ),
    ),
}


def get_strategy(strategy_id: str) -> StrategyPrompt:
    return STRATEGIES.get(strategy_id.lower(), STRATEGIES["msnr"])
