from typing import Literal

from pydantic import BaseModel, Field, field_validator


class AnalysisResponse(BaseModel):
    strategy: str
    instrument: str
    timeframe: str
    market_bias: Literal["Bullish", "Bearish", "Neutral", "No Trade"]
    setup_status: Literal["Valid", "Developing", "Invalid", "No Trade"]
    entry_zone: str
    stop_loss: str
    sl_pips: float = Field(ge=0, le=60)
    take_profit_targets: list[str] = Field(min_length=1, max_length=4)
    technical_confluence: list[str] = Field(min_length=1, max_length=8)
    invalidation: str
    analyst_note: str
    risk_note: str

    @field_validator("sl_pips", mode="before")
    @classmethod
    def cap_stop_loss(cls, value: object) -> float:
        try:
            return min(float(value), 60.0)
        except (TypeError, ValueError):
            return 60.0


class ErrorResponse(BaseModel):
    detail: str
