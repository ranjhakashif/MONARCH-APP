import base64
import json
import re
from typing import Any

import httpx

from .config import Settings
from .schemas import AnalysisResponse
from .strategies import StrategyPrompt


SYSTEM_PROMPT = """You are Monarch Analytics, an elite technical chart analyst.
You analyze only what is visible in the supplied chart image and the user context.
You do not guarantee profits, and you must clearly return No Trade when the chart is
unclear, missing essential context, or does not show a high-quality setup.

HARD RISK GUARDRAIL:
- Stop loss must never exceed 60 pips. This is non-negotiable.
- If a valid setup would require more than 60 pips, return No Trade instead.
- Never widen the stop loss to force a trade.
- Do not invent prices, indicators, levels, or a chart timeframe that are not visible.

Return ONLY valid JSON matching this shape:
{
  "market_bias": "Bullish | Bearish | Neutral | No Trade",
  "setup_status": "Valid | Developing | Invalid | No Trade",
  "entry_zone": "precise visible price zone or No Trade",
  "stop_loss": "price or No Trade",
  "sl_pips": 0,
  "take_profit_targets": ["target 1"],
  "technical_confluence": ["visible reason"],
  "invalidation": "what invalidates the thesis",
  "analyst_note": "concise institutional-style explanation",
  "risk_note": "risk and execution note"
}
"""


def _extract_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("Claude returned a response without a JSON object.")
    return json.loads(cleaned[start : end + 1])


async def analyze_chart(
    image_bytes: bytes,
    media_type: str,
    strategy: StrategyPrompt,
    instrument: str,
    timeframe: str,
    settings: Settings,
) -> AnalysisResponse:
    if not settings.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY is not configured.")

    user_prompt = f"""Strategy: {strategy.name}
Strategy subtitle: {strategy.subtitle}
Instrument supplied by user: {instrument or "Unknown"}
Timeframe supplied by user: {timeframe or "Unknown"}

Strategy-specific rules:
{strategy.rules}

Analyze this chart image. Use the supplied instrument and timeframe only as context;
if the image contradicts them or does not show them, say Unknown or No Trade. Include
precise levels only when readable. Return the exact JSON shape requested."""

    payload = {
        "model": settings.anthropic_model,
        "max_tokens": 8192,
        "system": SYSTEM_PROMPT,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": base64.b64encode(image_bytes).decode("ascii"),
                        },
                    },
                    {"type": "text", "text": user_prompt},
                ],
            }
        ],
    }

    headers = {
        "x-api-key": settings.anthropic_api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    async with httpx.AsyncClient(timeout=90.0) as client:
        response = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        body = response.json()

    text_blocks = [
        block.get("text", "")
        for block in body.get("content", [])
        if block.get("type") == "text"
    ]
    raw_text = "\n".join(text_blocks)
    parsed = _extract_json(raw_text)

    # The schema caps the number defensively, while this final check refuses
    # malformed output that tries to bypass the trading risk guardrail.
    sl_pips = float(parsed.get("sl_pips", 61))
    if sl_pips > 60:
        parsed.update(
            {
                "market_bias": "No Trade",
                "setup_status": "No Trade",
                "entry_zone": "No Trade — risk distance exceeds 60 pips",
                "stop_loss": "No Trade",
                "sl_pips": 60,
                "take_profit_targets": ["No Trade"],
                "invalidation": "The proposed stop loss exceeds Monarch's 60-pip maximum.",
                "analyst_note": "No execution is permitted because the risk distance is above the hard limit.",
                "risk_note": "Maximum stop-loss distance is 60 pips. Do not widen or force the setup.",
            }
        )
    parsed["strategy"] = strategy.name
    parsed["instrument"] = instrument or "Unknown"
    parsed["timeframe"] = timeframe or "Unknown"
    return AnalysisResponse.model_validate(parsed)
