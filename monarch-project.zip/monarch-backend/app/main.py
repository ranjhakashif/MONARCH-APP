from typing import Annotated

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .claude import analyze_chart
from .config import get_settings
from .schemas import AnalysisResponse
from .strategies import get_strategy

app = FastAPI(
    title="Monarch Analytics API",
    version="1.0.0",
    description="Vision-powered chart analysis for the Monarch trading platform.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "monarch-backend"}


@app.post("/analyze_monarch", response_model=AnalysisResponse)
async def analyze_monarch(
    chart: Annotated[UploadFile, File(description="PNG, JPEG, or WEBP chart screenshot")],
    strategy: Annotated[str, Form()] = "msnr",
    instrument: Annotated[str, Form()] = "",
    timeframe: Annotated[str, Form()] = "",
) -> AnalysisResponse:
    settings = get_settings()
    allowed_types = {"image/png", "image/jpeg", "image/webp"}
    if chart.content_type not in allowed_types:
        raise HTTPException(
            status_code=415,
            detail="Upload a PNG, JPEG, or WEBP chart screenshot.",
        )

    image_bytes = await chart.read()
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(image_bytes) == 0:
        raise HTTPException(status_code=400, detail="The chart screenshot is empty.")
    if len(image_bytes) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"Chart screenshots must be smaller than {settings.max_upload_mb} MB.",
        )

    try:
        return await analyze_chart(
            image_bytes=image_bytes,
            media_type=chart.content_type,
            strategy=get_strategy(strategy),
            instrument=instrument.strip(),
            timeframe=timeframe.strip(),
            settings=settings,
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Monarch analysis service error: {exc}",
        ) from exc
